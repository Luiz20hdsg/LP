firstPair([X,X]).
