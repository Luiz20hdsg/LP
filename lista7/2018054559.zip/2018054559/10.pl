max(X,Y,Z)  :-  X  =<  Y,!,  Y  =  Z.
   max(X,Y,X).

